## intent:goodbye  
- Bye 
- Goodbye
- See you later
- Bye bot
- Goodbye friend

## intent:greet
- Hi
- Hey
- Hi bot
- Hey bot
- Hello

## intent:thanks
- Thanks
- Thank you
- Thank you so much

## intent:affirm
- y
- Y
- yes
- yes sure
- absolutely

## intent:deny
- no
- never
- I don't think so

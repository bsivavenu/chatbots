# Weather_assistant
This is an assistant bot that can help you tell the weather for your city.
